# Catchup-prototype
Catch up prototype is a website which provides you with a great in-home tutoring experience. Through this website a qualified tutor is dispatched directly to your home and rule out the need to drive or go anywhere. Now, your child will get one-on-one attention, queries cleared up by well-trained and qualified professionals, as well as proper schedule will be maintained for each child which will include timely tests and assignments for the child’s performance, assuring their success for their better future.

TEAM MEMBERS
<br>
1.)<a href="https://github.com/Abhiman1211">Abhiman Gautam </a>
<br>
2.)<a href="https://github.com/Anshikasinha18">Anshika Sinha </a>








